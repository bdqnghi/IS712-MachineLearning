function loss = linearR_predict(X, Y, weights, bias)

	loss = ;

end
