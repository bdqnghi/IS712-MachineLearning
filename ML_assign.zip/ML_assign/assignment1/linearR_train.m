function [loss, weights, bias] = linearR_train(X, Y, weights, bias)

	loss = ;
    weights = ;
	bias = ;

end
