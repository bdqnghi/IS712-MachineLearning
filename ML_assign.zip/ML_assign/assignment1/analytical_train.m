function [loss, weights, bias] = analytical_train(X, Y, weights, bias)
	
	weights = ;
	bias    = ;
	loss    = ; 

end
