function loss = analytical_test(X, Y, weights, bias)

	loss = ;

end
